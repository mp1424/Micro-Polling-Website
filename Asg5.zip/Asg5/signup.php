<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    $email = $_POST['email'];
    $screenname = $_POST['screenname'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    // Perform validation checks (e.g., check if passwords match)

    // Insert data into the database
    // Assuming you have a database connection and query execution

    // Handle file upload (avatar image)
    if ($_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $targetDir = 'uploads/';
        $targetFile = $targetDir . basename($_FILES['avatar']['name']);
        move_uploaded_file($_FILES['avatar']['tmp_name'], $targetFile);

        // Save file location in the database
        $avatarUrl = $targetFile;
        // Update the user's avatar URL in the database
    }

    // Redirect to the Main Page
    header('Location: main.php');
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Signup</title>
    <link rel="stylesheet" type="text/css" href="css/Asg5.css">
    <script src="js/script.js"></script>
</head>
<body>
    <div id="container">
        <header id="header-auth">
            <h1>Please Sign Up to get login!</h1>
        </header>
        <section id="main-signup-left">
            <h2> * </h2>
        </section>
        <section id="main-signup-center">
            <h2 class="center">Fill in all details then click submit.</h2>
            <form class="auth-form" id="Signup" enctype="multipart/form-data>
                <p class="input-field">
            <!-- email input box -->
                    <label for="email">E-mail address:</label>
                    <input type="email" name="email" id="email">
                    <span id="error_email" class="error-text hidden">Email is invalid</span>
                </p>
                <p class="input-field">
                    <!-- screen name input box -->
                    <label for="screenname">Screenname:</label>
                    <input type="text" name="screenname" id="sname">
                    <span id="error_screenname" class="error-text hidden">Screenname is invalid</span>
                </p>
                <p class="input-field">
                    <!-- password input box -->
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password">
                    <span id="error_password" class="error-text hidden">Password is invalid</span>
                </p>
                <p class="input-field">
                    <!-- confirm password input box -->
                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" name="confirm_password" id="confirm_password">
                    <span id="error_cPassword" class="error-text hidden">Password is different</span>
                </p>
                <p class="input-field">
                    <!-- profile image input box -->
                    <label for="avatar">Avatar:</label>
                    <input type="file" name="avatar" id="avatar">
                    <span id="error_avatar" class="error-text hidden">Invalid Avatar</span>
                </p>
                <p class="input-field">
                    <input type="submit" value="Submit" id="signup">
                </p>
            </form>
        </section>
        <section id="main-signup-right">
            <h2 class="center"> Links </h2>
            <div class="foot-note">
                <!-- login link -->
                <p class="center"><a href="main.php">Login</a></p>
                <footer id="footer-auth">
                    <a href="https://validator.w3.org/nu/?doc=http%3A%2F%2Fwww.webdev.cs.uregina.ca%2F%7Empf544%2FAssignments%2FAsg5%2Fsignup.php">HTML Validator</a>
                </footer>
            </div>
        </section>
    </div>
</body>
</html>
