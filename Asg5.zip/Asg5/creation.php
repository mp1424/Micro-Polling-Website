<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = $_POST['question'];
    $answer1 = $_POST['answer1'];
    $answer2 = $_POST['answer2'];
    header('Location: poll_management.php');
    exit();
}
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Create Poll</title>
    <link rel="stylesheet" type="text/css" href="css/Asg5.css">
    <!-- This meta is required for CSS validation to work properly -->
    <script src="js/script.js"></script>
</head>
<body>
    <div id="container">
        <header id="header-auth">
            <h1>Fill all the fields and create your own poll.</h1>
        </header>
        <main id="main-signup-left">

        </main>
        <main id="main-signup-center">
            <form class="auth-form" action="creation.php" method="POST">
                <p class="input-field">
                    <label for="question">Question:</label>
                    <input type="text" name="question" required maxlength="255">
                </p>
                <p class="input-field">
                    <label for="answer1">Answer 1:</label>
                    <input type="text" name="answer1" required maxlength="100">
                </p>
                <p class="input-field">
                    <label for="answer2">Answer 2:</label>
                    <input type="text" name="answer2" required maxlength="100">
                </p>
                <p class="input-field">
                    <label for="answer3">Answer 3:</label>
                    <input type="text" name="answer3" maxlength="100">
                </p>
                <p class="input-field">
                    <label for="answer4">Answer 4:</label>
                    <input type="text" name="answer4" maxlength="100">
                </p>
                <p class="input-field">
                    <label for="answer5">Answer 5:</label>
                    <input type="text" name="answer5" maxlength="100">
                </p>
                <p class="input-field">
                    <label for="opendate">Open Date/Time:</label>
                    <input type="datetime-local" name="opendate" required>
                </p>
                <p class="input-field">
                    <label for="closedate">Close Date/Time:</label>
                    <input type="datetime-local" name="closedate" required>
                </p>
                <p class="input-field">
                    <input type="submit" value="Submit">
                </p>
            </form>
            <div class="foot-note">
                <!-- Login link -->
                <a href="main.html">Login here</a>
            </div>
        </main>
        <main id="main-signup-right">

        </main> 
    </div>
</body>
</html>
