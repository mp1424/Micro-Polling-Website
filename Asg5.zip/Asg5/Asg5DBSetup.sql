-- Clean up tables if present
DROP TABLE IF EXISTS Users, PollVotes, PollOptions, Polls;

-- Create the Users Table
CREATE TABLE Users (
    user_id INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    avatar_url VARCHAR(255),
    PRIMARY KEY (user_id)
);

-- Create the Polls Table
CREATE TABLE Polls (
    poll_id INT NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    question TEXT NOT NULL,
    status VARCHAR(20) NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (poll_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- Create the PollOptions Table
CREATE TABLE PollOptions (
    option_id INT NOT NULL AUTO_INCREMENT,
    poll_id INT NOT NULL,
    option_text TEXT NOT NULL,
    PRIMARY KEY (option_id),
    FOREIGN KEY (poll_id) REFERENCES Polls(poll_id)
);

-- Create the PollVotes Table
CREATE TABLE PollVotes (
    vote_id INT NOT NULL AUTO_INCREMENT,
    poll_id INT NOT NULL,
    option_id INT NOT NULL,
    user_id INT NOT NULL,
    voted_at DATETIME NOT NULL,
    PRIMARY KEY (vote_id),
    FOREIGN KEY (poll_id) REFERENCES Polls(poll_id),
    FOREIGN KEY (option_id) REFERENCES PollOptions(option_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);