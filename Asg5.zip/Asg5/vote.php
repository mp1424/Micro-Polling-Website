<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'mpf544');
define('DB_PASSWORD', 'Mp,1424');
define('DB_NAME', 'mpf544');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$errorMessage = '';

$poll_id = isset($_GET['poll_id']) ? $conn->real_escape_string($_GET['poll_id']) : null;
$row = null;

if ($poll_id !== null) {
    $query = "SELECT * FROM Polls WHERE id = $poll_id";
    $result = $conn->query($query);

    if ($result) {
        $row = $result->fetch_assoc();
    } else {
        echo "Error executing query: " . $conn->error;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pollId = $_POST['poll_id'];
    $selectedAnswer = $_POST['selected_answer'];
    
    // Insert voting data into the database
    
    // Redirect to Poll Results Page
    header('Location: poll_results.php?poll_id=' . $pollId);
    exit();
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Poll Vote Page</title>
    <link rel="stylesheet" type="text/css" href="css/Asg5.css">
    <script src="js/script.js"></script>
</head>
<body>
    <div id="container">
        <header id="header-auth">
            <h1>My Polls</h1>
            <img src="avatar.jpg" alt="User Avatar">
        </header>
        <main>
            <?php if ($row) { ?>
                <h2><?php echo $row['question']; ?></h2>
                <?php if (!empty($errorMessage)) { ?>
                    <p style="color: red;"><?php echo $errorMessage; ?></p>
                <?php } ?>
                <form method="post" action="">
                    <!-- Display answer alternatives -->
                    <ul class="answer-list">
                        <?php
                        // Loop through answer options
                        $answers = explode(',', $row['answer_options']);
                        foreach ($answers as $index => $answer) {
                            $answerId = "answer" . ($index + 1);
                            ?>
                            <li class="answer">
                                <input type="radio" id="<?php echo $answerId; ?>" name="option" value="<?php echo $answerId; ?>">
                                <label for="<?php echo $answerId; ?>"><?php echo $answer; ?></label>
                            </li>
                        <?php } ?>
                    </ul>
                    <button type="submit">Vote</button>
                </form>
                <div class="poll-info">
                    <div class="creator-info">
                        <span class="creator-screen-name">Poll Creator: <?php echo $row['creator_name']; ?></span>
                        <img src="<?php echo $row['creator_avatar']; ?>" alt="Poll Creator Avatar">
                    </div>
                </div>
            <?php } else { ?>
                <p>No poll found.</p>
            <?php } ?>
        </main>
        <footer>
            <p>CS 215: Web &amp; Database Programming</p>
            <p><a href="https://validator.w3.org/nu/?doc=http%3A%2F%2Fwww.webdev.cs.uregina.ca%2F%7Empf544%2FAssignments%2FAsg5%2Fvote.php">HTML VALIDATOR</a></p>
            <p>
                <a href="http://jigsaw.w3.org/css-validator/check/referer">
                    <img style="border:0;width:88px;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS">
                </a>
            </p>
        </footer>
    </div>
</body>
</html>
