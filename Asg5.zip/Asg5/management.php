<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: main.php');
    exit();
}

require_once("db.php");

$user_id = $_SESSION['user_id'];
$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT * FROM polls WHERE user_id = $user_id";
$result = $conn->query($query);

// Fetch all rows into an array
$polls = [];
while ($row = $result->fetch_assoc()) {
    $polls[] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>My Polls</title>
    <link rel="stylesheet" type="text/css" href="css/Asg5.css" />
    <!-- this meta is required for CSS validation to work properly -->
    <script src="js/script.js"></script>
</head>
<body>
    <div id="container">
        <header id="header-auth">
            <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
            <img src="images/Meet.jpeg" alt="User Avatar" class="align" />
        </header>
        <main>
            <ul>
                <?php foreach ($polls as $poll) { ?>
                    <li>
                        <?php echo $poll['question']; ?>
                        <a href="poll_vote.php?poll_id=<?php echo $poll['id']; ?>">Vote</a>
                        <a href="poll_results.php?poll_id=<?php echo $poll['id']; ?>">Results</a>
                    </li>
                <?php } ?>
            </ul>
            <h2>My Polls</h2>
            <ul id="poll-list">
                <?php foreach ($polls as $poll) { ?>
                    <li class="poll">
                        <div class="poll-info">
                            <span class="creation-time">Created: <?php echo $poll['creation_time']; ?></span>
                            <h3 class="question"><?php echo $poll['question']; ?></h3>
                            <ul class="answer-list">
                                <?php
                                // Loop through answer options and vote information
                                $answers = explode(',', $poll['answer_options']);
                                $votes = explode(',', $poll['vote_count']);
                                foreach ($answers as $index => $answer) {
                                    $votePercentage = ($votes[$index] / array_sum($votes)) * 100;
                                    ?>
                                    <li class="answer">
                                        <span class="answer-text"><?php echo $answer; ?></span>
                                        <div class="vote-bar">
                                            <div class="vote-progress" style="width: <?php echo $votePercentage; ?>%;"></div>
                                        </div>
                                        <span class="vote-count"><?php echo $votes[$index]; ?> votes</span>
                                    </li>
                                <?php } ?>
                            </ul>
                            <span class="recent-vote">Most Recent Vote: <?php echo $poll['recent_vote_time']; ?></span>
                        </div>
                    </li>
                <?php } ?>
            </ul>
            <a href="creation.php" alt="Please use this link for creating poll.">Create Poll</a><br>
            <a href="result.php" alt="Result Page">Results</a>
            <a href ="https://validator.w3.org/nu/?doc=http%3A%2F%2Fwww.webdev.cs.uregina.ca%2F%7Empf544%2FAssignments%2FAsg5%2Fmanagement.php" alt = "HTML">HTML VALIDATOR</a>
        </main>
    </div>
</body>
</html>
