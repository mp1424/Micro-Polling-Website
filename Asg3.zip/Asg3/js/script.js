//login starts
function validateEmail(email) {
    const emailRegex = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
    return emailRegex.test(email);
}

function validatePassword(password) {
    return password.length >= 8;
}

function validateLoginForm(event) {
    event.preventDefault();
    let isValid = true;

    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");
    const errorUsername = document.getElementById("error_username");
    const errorPassword = document.getElementById("error_password");

    const usernameValue = usernameInput.value.trim();
    const passwordValue = passwordInput.value.trim();

    
    if (!validateEmail(usernameValue)) {
        usernameInput.classList.add('invalid');
        errorUsername.classList.remove('hidden');
        isValid = false;
    } else {
        usernameInput.classList.remove('invalid');
        errorUsername.classList.add('hidden');
    }

    if (!validatePassword(passwordValue)) {
        passwordInput.classList.add('invalid');
        errorPassword.classList.remove('hidden');
        isValid = false;
    } else {
        passwordInput.classList.remove('invalid');
        errorPassword.classList.add('hidden');
    }

    if (isValid) {
        console.log("Login Validation successful, sending data to the server");
        event.target.submit();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.querySelector(".auth-form");
    if (loginForm) {
        loginForm.addEventListener('submit', validateLoginForm);
    }
});

//login ends

//signup starts

// Function to validate if an email address is in a valid format
function validateEmail(email) {
    const emailRegEx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegEx.test(email);
  }
  
  // Function to validate if a screen name is valid (no spaces or other non-word characters)
  function validateScreenName(screenName) {
    const screenNameRegEx = /^[a-zA-Z0-9_]+$/;
    return screenNameRegEx.test(screenName);
  }
  
  // Function to validate if a password is valid (8 characters long, at least one non-letter character)
  function validatePassword(password) {
    return password.length >= 8 && /\W/.test(password);
  }
  
  // Function to check if the confirm password matches the original password
  function validateConfirmPassword(password, confirmPassword) {
    return password === confirmPassword;
  }
  
  // Function to validate if an image file has a valid format 
  function validateAvatar(avatar) {
    const imageExtensions = ["jpg", "jpeg", "png", "gif"];
    const fileExtension = avatar.name.split('.').pop().toLowerCase();
    return imageExtensions.includes(fileExtension);
  }
  
  // Function to handle form submission and perform validation
  function validateSignupForm(event) {
    event.preventDefault();
    let isValid = true;
  
    const emailInput = document.getElementById("email");
    const screenNameInput = document.getElementById("sname");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirm_password");
    const avatarInput = document.getElementById("avatar");
  
    const errorEmail = document.getElementById("error_email");
    const errorScreenName = document.getElementById("error_screenname");
    const errorPassword = document.getElementById("error_password");
    const errorConfirmPassword = document.getElementById("error_cPassword");
    const errorAvatar = document.getElementById("error_avatar");
  
    const emailValue = emailInput.value.trim();
    const screenNameValue = screenNameInput.value.trim();
    const passwordValue = passwordInput.value;
    const confirmPasswordValue = confirmPasswordInput.value;
    const avatarValue = avatarInput.value;
  
    // Validate email
    if (!validateEmail(emailValue)) {
      emailInput.classList.add('invalid');
      errorEmail.classList.remove('hidden');
      isValid = false;
    } else {
      emailInput.classList.remove('invalid');
      errorEmail.classList.add('hidden');
    }
  
    // Validate screen name
    if (!validateScreenName(screenNameValue)) {
      screenNameInput.classList.add('invalid');
      errorScreenName.classList.remove('hidden');
      isValid = false;
    } else {
      screenNameInput.classList.remove('invalid');
      errorScreenName.classList.add('hidden');
    }
  
    // Validate password
    if (!validatePassword(passwordValue)) {
      passwordInput.classList.add('invalid');
      errorPassword.classList.remove('hidden');
      isValid = false;
    } else {
      passwordInput.classList.remove('invalid');
      errorPassword.classList.add('hidden');
    }
  
    // Validate confirm password
    if (!validateConfirmPassword(passwordValue, confirmPasswordValue)) {
      confirmPasswordInput.classList.add('invalid');
      errorConfirmPassword.classList.remove('hidden');
      isValid = false;
    } else {
      confirmPasswordInput.classList.remove('invalid');
      errorConfirmPassword.classList.add('hidden');
    }
  
    // Validate avatar
    if (!validateAvatar(avatarInput.files[0])) {
      avatarInput.classList.add('invalid');
      errorAvatar.classList.remove('hidden');
      isValid = false;
    } else {
      avatarInput.classList.remove('invalid');
      errorAvatar.classList.add('hidden');
    }
  
    // If the form is valid, submit the form
    if (isValid) {
      console.log("Signup Validation successful, sending data to the server");
      event.target.submit();
    }
  }
  
  document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById("Signup");
    if (signupForm) {
      signupForm.addEventListener('submit', validateSignupForm);
    }
  });
  

//signup ends

//creation starts

// Function to validate if a date/time input has a valid format
function isValidDateTime(dateTimeString) {
    const dateTime = new Date(dateTimeString);
    return !isNaN(dateTime);
  }
  
  // Function to validate the Poll Creation Form
  function validatePollCreationForm(event) {
    event.preventDefault();
    let formIsValid = true;
  
    const questionInput = document.querySelector('input[name="question"]');
    const openDateInput = document.querySelector('input[name="opendate"]');
    const closeDateInput = document.querySelector('input[name="closedate"]');
    const answerInputs = document.querySelectorAll('input[name^="answer"]');
  
    const errorQuestion = document.getElementById("error_question");
    const errorOpenDate = document.getElementById("error_dt");
    const errorCloseDate = document.getElementById("error_dt");
  
    // Validate question
    if (!questionInput.value.trim() || questionInput.value.length > 100) {
      questionInput.classList.add('invalid');
      errorQuestion.classList.remove('hidden');
      formIsValid = false;
    } else {
      questionInput.classList.remove('invalid');
      errorQuestion.classList.add('hidden');
    }
  
    // Validate answers
    answerInputs.forEach((input, index) => {
      if (input.value.length > 50) {
        input.classList.add('invalid');
        document.getElementById("error_ans" + (index + 1)).classList.remove('hidden');
        formIsValid = false;
      } else {
        input.classList.remove('invalid');
        document.getElementById("error_ans" + (index + 1)).classList.add('hidden');
      }
    });
  
    // Validate open date/time
    if (!isValidDateTime(openDateInput.value)) {
      openDateInput.classList.add('invalid');
      errorOpenDate.classList.remove('hidden');
      formIsValid = false;
    } else {
      openDateInput.classList.remove('invalid');
      errorOpenDate.classList.add('hidden');
    }
  
    // Validate close date/time
    if (!isValidDateTime(closeDateInput.value)) {
      closeDateInput.classList.add('invalid');
      errorCloseDate.classList.remove('hidden');
      formIsValid = false;
    } else {
      closeDateInput.classList.remove('invalid');
      errorCloseDate.classList.add('hidden');
    }
  
    // If the form is valid, submit the form
    if (formIsValid) {
      console.log("Poll Creation Form validation successful, sending data to the server");
      event.target.submit();
    }
  }
  
  document.addEventListener('DOMContentLoaded', () => {
    const pollCreationForm = document.getElementById("pollcreationForm");
    if (pollCreationForm) {
      pollCreationForm.addEventListener('submit', validatePollCreationForm);
    }
  });
  
  
  document.addEventListener('DOMContentLoaded', function () {
    // Attach character counter to each input field
    const inputFields = document.querySelectorAll('.input-field input[type="text"]');
    inputFields.forEach((input) => {
      input.addEventListener('input', function () {
        const maxChar = parseInt(input.getAttribute('maxlength'), 10);
        const currentChar = input.value.length;
        const counterElement = getCounterElement(input);
  
        if (currentChar <= maxChar) {
          counterElement.textContent = `${currentChar}/${maxChar}`;
          counterElement.classList.remove('error');
        } else {
          counterElement.textContent = `${currentChar}/${maxChar} (Exceeded)`;
          counterElement.classList.add('error');
        }
      });
    });
  
    // Attach character counter to datetime-local inputs
    const dateTimeInputs = document.querySelectorAll('.input-field input[type="datetime-local"]');
    dateTimeInputs.forEach((input) => {
      input.addEventListener('input', function () {
        const counterElement = getCounterElement(input);
        counterElement.textContent = ''; // Clear the counter for datetime inputs
      });
    });
  
    function getCounterElement(input) {
      const parent = input.parentElement;
      const existingCounter = parent.querySelector('.char-counter');
      if (existingCounter) {
        return existingCounter;
      }
  
      const counter = document.createElement('span');
      counter.classList.add('char-counter');
      parent.appendChild(counter);
      return counter;
    }
  });
  

//creation ends