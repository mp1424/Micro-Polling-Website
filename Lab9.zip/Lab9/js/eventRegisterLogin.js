var form = document.getElementById("login-form");
form.addEventListener("submit", validateLogin);
