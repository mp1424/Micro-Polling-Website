<?php
// Create a logout.php page with PHP code that starts a session, unsets and destroys it, then redirects back to login.php
session_start();
session_unset();
session_destroy();
header('Location: login.php');
exit;
?>