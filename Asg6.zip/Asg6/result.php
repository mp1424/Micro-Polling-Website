<?php
require_once("db.php");

define('DB_HOST', 'localhost');
define('DB_USER', 'mpf544');
define('DB_PASSWORD', 'Mp,1424');
define('DB_NAME', 'mpf544');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME); 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

$poll_id = isset($_GET['poll_id']) ? $_GET['poll_id'] : null;
$poll_row = null; 
$results = array();

if ($poll_id !== null) {
    $poll_query = "SELECT * FROM Poll WHERE poll_id = $poll_id";
    $poll_result = $conn->query($poll_query);
    
    if ($poll_result && $poll_result->num_rows > 0) {
        $poll_row = $poll_result->fetch_assoc();
    }
    
    $results_query = "SELECT * FROM PollOptions WHERE poll_id = $poll_id";
    $results_result = $conn->query($results_query);
    
    if ($results_result && $results_result->num_rows > 0) {
        while ($row = $results_result->fetch_assoc()) {
            $results[] = $row;
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Poll Results</title>
    <link rel="stylesheet" type="text/css" href="css/Asg6.css">
    <script src="js/script.js"></script>
</head>
<body>
    <header id="header-auth">
        <h1>Results</h1>
        <img src="" alt="user avatar">
    </header>
    <div id="container">
        <main>
            <?php if ($poll_row !== null) { ?>
            <h2><?php echo $poll_row['question']; ?></h2>
            <ul>
                <?php foreach ($results as $row) { ?>
                    <li><?php echo $row['option_text']; ?>: <?php echo $row['votes']; ?> votes</li>
                <?php } ?>
            </ul>
            <?php } else { ?>
            <p>No poll results available.</p>
            <?php } ?>
        </main>
    </div>
    <footer>
        <p>CS 215: Web &amp; Database Programming</p>
        <p><a href="https://validator.w3.org/nu/?doc=http%3A%2F%2Fwww.webdev.cs.uregina.ca%2F%7Empf544%2FAssignments%2FAsg5%2Fresult.php">HTML VALIDATOR</a></p>
        <p>
            <a href="http://jigsaw.w3.org/css-validator/check/referer">
                <img style="border:0;width:88px;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS">
            </a>
        </p>
    </footer>
</body>
</html>
