<?php
require("db.php");
define('DB_HOST', 'localhost');
define('DB_USER', 'mpf544');
define('DB_PASSWORD', 'Mp,1424');
define('DB_NAME', 'mpf544');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

$pollId = $_POST['poll_id'];
$selectedAnswer = $_POST['selected_answer'];

$query = "SELECT * FROM Polls WHERE id = $pollId";
$result = $conn->query($query);

if ($result) {
    $row = $result->fetch_assoc();
    $answers = explode(',', $row['answer_options']);
    
    $updatedHtml = '';
    foreach ($answers as $index => $answer) {
        $answerId = "answer" . ($index + 1);
        $voteCount = 0; // Replace this with the actual vote count for each answer
        
        $updatedHtml .= '<li class="answer">' . 
                        '<span>' . $answer . '</span>' . 
                        '<span class="vote-count">' . $voteCount . ' votes</span>' .
                        '</li>';
    }
    
    echo $updatedHtml;
} else {
    echo "Error executing query: " . $conn->error;
}
?>
