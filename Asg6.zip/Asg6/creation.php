<?php
require("db.php");

define('DB_HOST', 'localhost');
define('DB_USER', 'mpf544');
define('DB_PASSWORD', 'Mp,1424');
define('DB_NAME', 'mpf544');

session_start();
$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = $_POST['question'];
    $answer_1 = $_POST['answer_1']; 
    $answer_2 = $_POST['answer_2'];
    $answer_3 = $_POST['answer_3'];
    $answer_4 = $_POST['answer_4'];
    $answer_5 = $_POST['answer_5'];
    $open_datetime = $_POST['opendate'];
    $close_datetime = $_POST['closedate'];

    $sql = "INSERT INTO Poll (question, answer_1, answer_2, answer_3, answer_4, answer_5, open_datetime, close_datetime) VALUES ('$question', '$answer_1', '$answer_2', '$answer_3', '$answer_4', '$answer_5', '$open_datetime', '$close_datetime') ";
    
    if ($conn->query($sql) === TRUE) {
        echo "Poll creation successful!";
        // header('Location: management.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>
 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Create Poll</title>
    <link rel="stylesheet" type="text/css" href="css/Asg6.css">
    <!-- This meta is required for CSS validation to work properly -->
    <script src="js/script.js"></script>
</head>
<body>
    <div id="container">
        <header id="header-auth">
            <h1>Fill all the fields and create your own poll.</h1>
        </header>
        <main id="main-signup-left">

        </main>
        <main id="main-signup-center">
        <form id="pollcreationForm" class="auth-form" action="creation.php" enctype="multipart/form-data" method="post">
    <p class="input-field">
        <label for="question">Question:</label>
        <input type="text" name="question" required maxlength="255">
        <span id="error_question" class="error-text hidden">Question is invalid</span>
    </p>
    <p class="input-field">
        <label for="answer_1">Answer 1:</label>
        <input type="text" name="answer_1" required maxlength="100">
        <span id="error_answer1" class="error-text hidden">Answer is invalid</span>
    </p>
    <p class="input-field">
        <label for="answer_2">Answer 2:</label>
        <input type="text" name="answer_2" required maxlength="100">
        <span id="error_answer2" class="error-text hidden">Answer is invalid</span>
    </p>
    <p class="input-field">
        <label for="answer_3">Answer 3:</label>
        <input type="text" name="answer_3" required maxlength="100">
        <span id="error_answer3" class="error-text hidden">Answer is invalid</span>
    </p>
    <p class="input-field">
        <label for="answer_4">Answer 4:</label>
        <input type="text" name="answer_4" required maxlength="100">
        <span id="error_answer4" class="error-text hidden">Answer is invalid</span>
    </p>
    <p class="input-field">
        <label for="answer_5">Answer 5:</label>
        <input type="text" name="answer_5" required maxlength="100">
        <span id="error_answer5" class="error-text hidden">Answer is invalid</span>
    </p>
    <p class="input-field">
        <label for="opendate">Open Date/Time:</label>
        <input type="datetime-local" name="opendate" required>
        <span id="error_opendatetime" class="error-text hidden">Date/time is invalid</span>
    </p>
    <p class="input-field">
        <label for="closedate">Close Date/Time:</label>
        <input type="datetime-local" name="closedate" required>
        <span id="error_closedatetime" class="error-text hidden">Date/time is invalid</span>
    </p>
    <p class="input-field">
        <input type="submit" value="Submit" id="create">
    </p>
</form>

        </main>
            <div class="foot-note">
                <!-- Login link -->
                <a href="login.php">Login here</a> 
            </div>
        
        <main id="main-signup-right">

        </main> 
    </div>
</body>
</html>
