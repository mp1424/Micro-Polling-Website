<?php
require("db.php");

define('DB_HOST', 'localhost');
define('DB_USER', 'mpf544');
define('DB_PASSWORD', 'Mp,1424');
define('DB_NAME', 'mpf544');
session_start();
$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$polls = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM Users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: management.php");
            exit;
        } else {
            $error = "Invalid password";
        }
    } else {
        $error = "User not found";
    }
}

$query = "SELECT * FROM Poll";
$result = $conn->query($query);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $polls[] = $row;
    }
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ASG-6</title>
    <link rel="stylesheet" type="text/css" href="css/Asg6.css">
    <!-- This meta is not required for CSS validation -->
    <script src="js/script.js"></script>
</head>

<body>
    <div id="container">
        <header id="header-auth">
            <h1>Latino Micro Polling Page</h1>
        </header>
        <section id="main-left">
            <h2>Recent Active Polls</h2>
            <ul class="poll-list">
                <?php foreach ($polls as $row) { ?>
                    <li class="poll">
                        <h3 class="poll-question"><?php echo $row['question']; ?></h3>
                        <span class="poll-creator">Created by: <?php echo $row['user_id']; ?></span>
                    </li>
                <?php } ?>
            </ul>
        </section>
        <section id="main-center">
            <h2 class="center">*</h2>
        </section>
        <section id="main-right">
            <h2 class="center">Login</h2>
            <form class="auth-form" action="management.php" method="post">
                <p class="input-field">
                    <!-- username box -->
                    <label for="username">Username:</label>
                    <input type="email" name="username" id="username">
                    <span id="error_username" class="error-text hidden">Username is invalid</span>
                </p>
                <p class="input-field">
                    <!-- password box -->
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password">
                    <span id="error_password" class="error-text hidden">Password is invalid</span>
                </p>
                <p class="input-field">
                    <input type="submit" class="form-submit" value="Login">
                </p>
                <br>
                <br>
                <?php if (isset($error)) { echo "<p>$error</p>"; } ?>

                <p>Don't have an account? <a href="signup.php">Sign up</a></p>
                <p>Love to vote? <a href="vote.php">Vote here</a></p>
                <p>View official poll <a href="result.php">results</a></p>
                <a href="https://validator.w3.org/nu/?doc=http%3A%2F%2Fwww.webdev.cs.uregina.ca%2F%7Empf544%2FAssignments%2FAsg5%2Fmain.php">Html Validator</a>
            </form>
        </section>
</body>
</html>
