<?php
require("db.php");

define('DB_HOST', 'localhost');
define('DB_USER', 'mpf544');
define('DB_PASSWORD', 'Mp,1424');
define('DB_NAME', 'mpf544');
session_start();
$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$errorMessage = '';

// No specific poll selected, show all active polls
$query = "SELECT * FROM Poll WHERE NOW() BETWEEN open_datetime AND close_datetime";
$result = $conn->query($query);

$activePolls = array();

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $activePolls[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Poll Vote Page</title>
    <link rel="stylesheet" type="text/css" href="css/Asg6.css">
    <script src="js/script.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.answer input[type="radio"]').on('change', function() {
                var selectedAnswer = $(this).val();
                var pollId = <?php echo $row['poll_id']; ?>;

                $.ajax({
                    type: 'POST',
                    url: 'process_vote.php', 
                    data: {
                        poll_id: pollId,
                        selected_answer: selectedAnswer
                    },
                    success: function(response) {
                        $('.answer-list').html(response);
                    }
                });
            });
        });
    </script>
</head>
<body>
    <div id="container">
        <header id="header-auth">
            <h1>My Polls</h1>
            <img src="avatar.jpg" alt="User Avatar">
        </header>
        <main>
            <?php if (!empty($activePolls)) { ?>
                <?php foreach ($activePolls as $row) { ?>
                    <h2><?php echo $row['question']; ?></h2>
                    <?php if (!empty($errorMessage)) { ?>
                        <p style="color: red;"><?php echo $errorMessage; ?></p>
                    <?php } ?>
                    <form method="post" action="">
                        <ul class="answer-list">
                            <?php
                            $answers = explode(',', $row['poll_id']);
                            foreach ($answers as $index => $answer) {
                                $answerId = "answer" . ($index + 1);
                                ?>
                                <li class="answer">
                                    <input type="radio" id="<?php echo $answerId; ?>" name="selected_answer" value="<?php echo $answerId; ?>">
                                    <label for="<?php echo $answerId; ?>"><?php echo $answer; ?></label>
                                </li>
                            <?php } ?>
                        </ul>
                        <input type="hidden" name="poll_id" value="<?php echo $row['poll_id']; ?>">
                        <button type="submit">Vote</button>
                    </form>
                    <div class="poll-info">
                        <div class="creator-info">
                            <?php
                            $creatorId = $row['user_id'];
                            $creatorQuery = "SELECT * FROM Users WHERE id = $creatorId";
                            $creatorResult = $conn->query($creatorQuery);
                            if ($creatorResult && $creatorResult->num_rows > 0) {
                                $creator = $creatorResult->fetch_assoc();
                                ?>
                                <span class="creator-screen-name">Poll Creator: <?php echo $creator['screenname']; ?></span>
                                <img src="<?php echo $creator['avatar_url']; ?>" alt="Avatar">
                            <?php } else { ?>
                                <span class="creator-screen-name">Poll Creator: Unknown</span>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <p>No active polls found.</p>
            <?php } ?>
        </main>
        <footer>
            <p>CS 215: Web &amp; Database Programming</p>
            <p><a href="https://validator.w3.org/nu/?doc=http%3A%2F%2Fwww.webdev.cs.uregina.ca%2F%7Empf544%2FAssignments%2FAsg5%2Fvote.php">HTML VALIDATOR</a></p>
            <p>
                <a href="http://jigsaw.w3.org/css-validator/check/referer">
                    <img style="border:0;width:88px;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS">
                </a>
            </p>
        </footer>
    </div>
</body>
</html>
