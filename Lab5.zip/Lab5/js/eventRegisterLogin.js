// Todo 4: Add code to register a "submit" event on the login form, 
//         and assign an event handler.
//         Hint: use addEventListener() to register events.

const loginForm = document.getElementById("login");
loginForm.addEventListener("submit", validateLogin);