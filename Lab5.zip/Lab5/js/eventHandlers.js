function validateName(name) {
  let nameRegEx = /^[a-zA-Z]+$/;
  return nameRegEx.test(name);
}

function validatePassword(password) {
  return password.length === 8;
}

function validateDateOfBirth(dateOfBirth) {
  let dateOfBirthRegEx = /^\d{4}[-]\d{2}[-]\d{2}$/;
  return dateOfBirthRegEx.test(dateOfBirth);
}

function validateAvatar(avatar) {
  let avatarRegEx = /^[^\n]+\.[a-zA-Z]{3,4}$/;
  return avatarRegEx.test(avatar);
}

function validateUsername(username) {
  let usernameRegEx = /^[a-zA-Z0-9_]+$/;
  return usernameRegEx.test(username);
}

function validateSignup() {
  let formIsValid = true;

  let firstName = document.getElementById("firstName");
  if (!validateName(firstName.value)) {
    console.log("'" + firstName.value + "' is not a valid first name");
    formIsValid = false;
  }

  let lastName = document.getElementById("lastName");
  if (!validateName(lastName.value)) {
    console.log("'" + lastName.value + "' is not a valid last name");
    formIsValid = false;
  }

  let password = document.getElementById("password");
  if (!validatePassword(password.value)) {
    console.log("Password must be exactly 8 characters long");
    formIsValid = false;
  }

  let confirmPassword = document.getElementById("confirmPassword");
  if (password.value !== confirmPassword.value) {
    console.log("Password and confirm password fields do not match");
    formIsValid = false;
  }

  let avatar = document.getElementById("avatar");
  if (!validateAvatar(avatar.value)) {
    console.log("'" + avatar.value + "' is not a valid avatar");
    formIsValid = false;
  }

  if (formIsValid === false) {
    console.log("Signup form has invalid fields. Please fix the errors.");
    event.preventDefault();
  } else {
    console.log("Validation successful, sending data to the server");
  }
}

function validateLogin(event) {
  event.preventDefault();

  let username = document.getElementById("username");
  let password = document.getElementById("password");

  if (!validateUsername(username.value)) {
    console.log("'" + username.value + "' is not a valid username");
    return;
  }

  if (!validatePassword(password.value)) {
    console.log("Password must be exactly 8 characters long");
    return;
  }

  console.log("Validation successful, sending data to the server");
}

function firstNameHandler(event) {
  let firstName = event.target;
  if (!validateName(firstName.value)) {
    console.log("'" + firstName.value + "' is not a valid first name");
  }
}

function lastNameHandler(event) {
  let lastName = event.target;
  if (!validateName(lastName.value)) {
    console.log("'" + lastName.value + "' is not a valid last name");
  }
}

function passwordHandler(event) {
  let password = event.target;
  if (!validatePassword(password.value)) {
    console.log("Password must be exactly 8 characters long");
  }
}

function confirmPasswordHandler(event) {
  let password = document.getElementById("password");
  let confirmPassword = event.target;
  if (password.value !== confirmPassword.value) {
    console.log("Password and confirm password fields do not match");
  }
}

function avatarHandler(event) {
  let avatar = event.target;
  if (!validateAvatar(avatar.value)) {
    console.log("'" + avatar.value + "' is not a valid avatar");
  }
}

function usernameHandler(event) {
  let username = event.target;
  if (!validateUsername(username.value)) {
    console.log("'" + username.value + "' is not a valid username");
  }
}

function dateOfBirthHandler(event) {
  let dateOfBirth = event.target;
  if (!validateDateOfBirth(dateOfBirth.value)) {
    console.log("'" + dateOfBirth.value + "' is not a valid date of birth");
  }
}

let loginForm = document.getElementById("login")
loginForm.addEventListener("submit", validateLogin);

let signupForm = document.getElementById("signupForm");
signupForm.addEventListener("submit", validateSignup);

let firstNameInput = document.getElementById("firstName");
firstNameInput.addEventListener("blur", firstNameHandler);

let lastNameInput = document.getElementById("lastName");
lastNameInput.addEventListener("blur", lastNameHandler);

let passwordInput = document.getElementById("password");
passwordInput.addEventListener("blur", passwordHandler);

let confirmPasswordInput = document.getElementById("confirmPassword");
confirmPasswordInput.addEventListener("blur", confirmPasswordHandler);

let avatarInput = document.getElementById("avatar");
avatarInput.addEventListener("blur", avatarHandler);

let usernameInput = document.getElementById("username");
usernameInput.addEventListener("blur", usernameHandler);

let dateOfBirthInput = document.getElementById("dateOfBirth");
dateOfBirthInput.addEventListener("blur", dateOfBirthHandler);
