let firstName = document.getElementById("firstName");
firstName.addEventListener("change", firstNameHandler);

let lastName = document.getElementById("lastName");
lastName.addEventListener("change", lastNameHandler);

let password = document.getElementById("password");
password.addEventListener("change", passwordHandler);

let confirmPassword = document.getElementById("confirmPassword");
confirmPassword.addEventListener("change", confirmPasswordHandler);

let avatar = document.getElementById("profilePhoto");
avatar.addEventListener("change", avatarHandler);


let userName = document.getElementById("userName");
userName.addEventListener("blur", userNameHandler);

let dateOfBirth = document.getElementById("dateOfBirth");
dateOfBirth.addEventListener("blur", dateOfBirthHandler);
